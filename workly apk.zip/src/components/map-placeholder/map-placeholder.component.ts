import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'app-map-placeholder',
  templateUrl: './map-placeholder.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MapPlaceholderComponent {}
