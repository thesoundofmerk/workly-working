import { BaseSession } from './session.model';

export interface CanvassingSession extends BaseSession {
  doorHangersPlaced: number;
}